package com.example.bony.trackdistancetravel;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import static java.lang.Math.PI;

public class Activity2 extends AppCompatActivity implements LocationListener {

    LocationManager locationManager;
    String mprovider;
    double lat1, lat2, long1, long2, dlat, dlong, a, d, c;
    double r = 6371;
   public static boolean start;
    Location location;
    TextView Distance;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        Distance = (TextView) findViewById(R.id.distance);
        if(start)
        StartLocationTracking();


    }

    public void StartLocationTracking() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();

        mprovider = locationManager.getBestProvider(criteria, false);
        if (Distance.getText().equals("0")) {
            location = locationManager.getLastKnownLocation(mprovider);
            lat1 = location.getLatitude();
            long1 = location.getLongitude();
            d = 0;
        }

        if (mprovider != null && !mprovider.equals("")) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.requestLocationUpdates(mprovider, 10000, 1, this);
            location = locationManager.getLastKnownLocation(mprovider);


            onLocationChanged(location);

        }
    }



    @Override
    public void onLocationChanged(Location location) {

       lat2=location.getLatitude();
        long2=location.getLongitude();
         dlat=deg2rad(lat2-lat1);
        dlong=deg2rad(long2-long1);
        a = Math.sin(dlat/2) * Math.sin(dlat/2)+Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dlong/2) * Math.sin(dlong/2);
        c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
         d = r * c;// Distance in km

       Distance.setText(d +"Km");
        lat1=lat2;
        long1=long2;



    }

 public double deg2rad(double deg) {
        return deg * (PI/180);
    }
    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }
}
